﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace POSD_Tema1.Models
{
    public class UserModel
    {
        public string username { get; set; }
        public string password { get; set; }
        public string newUsername { get; set; }
        public string newPassword { get; set; }
    }
}